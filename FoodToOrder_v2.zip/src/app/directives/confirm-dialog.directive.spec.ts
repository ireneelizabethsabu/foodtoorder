import { ConfirmDialogDirective } from './confirm-dialog.directive';

describe('ConfirmDialogDirective', () => {
  it('should create an instance', () => {
    const directive = new ConfirmDialogDirective();
    expect(directive).toBeTruthy();
  });
});
